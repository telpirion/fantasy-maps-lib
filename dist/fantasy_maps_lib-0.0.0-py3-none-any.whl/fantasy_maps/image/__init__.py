"""
fantasy_maps.

A processor of fantasy virtual table top (VTT) maps, powered by Vertex AI
"""

__version__ = "0.1.0"
__author__ = "Eric Schmidt"
__credits__ = "Google, LLC"
