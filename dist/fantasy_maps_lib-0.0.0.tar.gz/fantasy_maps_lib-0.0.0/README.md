# fantasy-maps-lib
A Python library for working with fantasy maps images.
